<?php

echo '<div id="footer">';
echo '    <a href="#">CONTACT US</a>';
echo '    <p>WALNUT RIDGE LEATHER COMPANY</p>';
echo '    <p>ORRVILLE, OHIO</p>';
echo '    <a href="mailto:test@test.com">WALNUTRIDGELEATHERCOMPANY@GMAIL.COM</a>';
echo '</div>';

?>