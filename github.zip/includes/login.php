<link rel="stylesheet" href="css/admin.css">
<form name="admin_login" action="admin.php" method="POST">
        <div class="text-center ">
            
            <label for="username">Username:</label> <input type="text" class="adminField" name="username" value="">
    
            <label for="admin_password">Password:</label> 
            <input type="password" class="adminField" name="admin_password" value="">
        </div>
        
        <div class="text-center">
            <input type="submit" class="adminButton" id="adminLogin" name="submit" value="LOGIN">
        </div>
</form>